package com.gamebooster.app.service

import android.app.*
import android.app.NotificationManager as SysNotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.gamebooster.app.data.DeviceStats
import kotlinx.coroutines.*

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var handleView: View? = null
    private var panelView: View? = null
    private var isPanelOpen = false

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var statsJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(NOTIF_ID, buildNotification())
        addHandle()
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    /** The small pull-tab docked to the left edge - matches the Design mockup's swipe handle. */
    private fun addHandle() {
        val handle = TextView(this).apply {
            text = "›"
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadii = floatArrayOf(0f, 0f, 24f, 24f, 24f, 24f, 0f, 0f)
                colors = intArrayOf(Color.parseColor("#8B5CFF"), Color.parseColor("#5B2FE0"))
                orientation = GradientDrawable.Orientation.LEFT_RIGHT
            }
        }

        val params = WindowManager.LayoutParams(
            dp(16), dp(70),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 600
        }

        var downRawY = 0f
        var startY = 0
        var moved = false

        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawY = event.rawY
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (event.rawY - downRawY).toInt()
                    if (kotlin.math.abs(dy) > 8) moved = true
                    params.y = startY + dy
                    windowManager.updateViewLayout(handle, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) openPanel()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(handle, params)
        handleView = handle
    }

    private fun openPanel() {
        if (isPanelOpen) return
        isPanelOpen = true
        handleView?.visibility = View.GONE

        val root = buildPanel()
        val params = WindowManager.LayoutParams(
            dp(240), WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = 160
        }

        windowManager.addView(root, params)
        panelView = root

        statsJob = serviceScope.launch {
            while (isActive) {
                refreshStats(root)
                delay(2000)
            }
        }
    }

    private fun closePanel() {
        panelView?.let { windowManager.removeView(it) }
        panelView = null
        isPanelOpen = false
        statsJob?.cancel()
        handleView?.visibility = View.VISIBLE
    }

    private fun buildPanel(): View {
        val ctx = this
        val dndEnabled = (getSystemService(Context.NOTIFICATION_SERVICE) as SysNotificationManager)
            .let { nm -> nm.currentInterruptionFilter != SysNotificationManager.INTERRUPTION_FILTER_ALL }

        val container = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#E60C0A16"))
                setStroke(dp(1), Color.parseColor("#8B5CFF"))
            }
        }

        fun label(text: String, size: Float = 12f, color: String = "#C6CCDA") = TextView(ctx).apply {
            this.text = text
            setTextColor(Color.parseColor(color))
            textSize = size
        }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(label("⚡ Game Booster", 14f, "#FFFFFF").apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            val close = TextView(ctx).apply {
                text = "✕"
                setTextColor(Color.parseColor("#C26CFF"))
                setPadding(dp(8), 0, 0, 0)
                setOnClickListener { closePanel() }
            }
            addView(close)
        }
        container.addView(header)
        container.addView(spacer(8))

        val statsRow = TextView(ctx).apply { tag = "stats" }
        statsRow.setTextColor(Color.parseColor("#EAF0FA"))
        statsRow.textSize = 12f
        container.addView(statsRow)
        container.addView(spacer(10))

        // Do Not Disturb toggle - real, via NotificationManager
        val dndRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        dndRow.addView(label("Do Not Disturb").apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        val dndSwitch = Switch(ctx).apply {
            isChecked = dndEnabled
            setOnCheckedChangeListener { _, checked -> setDnd(checked) }
        }
        dndRow.addView(dndSwitch)
        container.addView(dndRow)
        container.addView(spacer(6))

        // Performance mode cycle button - calls into Booster (rooted devices get a real governor switch)
        val perfRow = label("Performance Mode: tap to cycle", 11f, "#C26CFF")
        perfRow.setOnClickListener {
            cyclePerformanceMode(perfRow)
        }
        container.addView(perfRow)
        container.addView(spacer(6))

        val screenshotRow = label("📷 Screenshot", 12f, "#EAF0FA")
        screenshotRow.setOnClickListener {
            startActivity(
                Intent(ctx, ScreenCaptureService.RequestActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        container.addView(screenshotRow)

        return container
    }

    private var currentMode = com.gamebooster.app.data.PerformanceMode.GAMING

    private fun cyclePerformanceMode(label: TextView) {
        currentMode = when (currentMode) {
            com.gamebooster.app.data.PerformanceMode.GAMING -> com.gamebooster.app.data.PerformanceMode.BALANCED
            com.gamebooster.app.data.PerformanceMode.BALANCED -> com.gamebooster.app.data.PerformanceMode.POWER_SAVING
            com.gamebooster.app.data.PerformanceMode.POWER_SAVING -> com.gamebooster.app.data.PerformanceMode.GAMING
        }
        serviceScope.launch {
            val applied = com.gamebooster.app.data.Booster.applyPerformanceMode(currentMode)
            val note = if (applied) "" else " (needs root)"
            label.text = "Performance Mode: ${currentMode.name}$note"
        }
    }

    private fun setDnd(enable: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as SysNotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(
                Intent(SysNotificationManager.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        nm.setInterruptionFilter(
            if (enable) SysNotificationManager.INTERRUPTION_FILTER_PRIORITY
            else SysNotificationManager.INTERRUPTION_FILTER_ALL
        )
    }

    private fun refreshStats(root: View) {
        val statsView = root.findViewWithTag<TextView>("stats") ?: return
        serviceScope.launch {
            val snap = DeviceStats.snapshot(this@OverlayService)
            statsView.text = "FPS ${snap.refreshRateHz}Hz   RAM ${snap.ramUsedPercent}%   " +
                "Temp ${snap.batteryTempC}°C   Batt ${snap.batteryPercent}%"
        }
    }

    private fun spacer(heightDp: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(heightDp))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Game Booster overlay", SysNotificationManager.IMPORTANCE_MIN
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as SysNotificationManager)
                .createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Game Booster is running")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        handleView?.let { runCatching { windowManager.removeView(it) } }
        panelView?.let { runCatching { windowManager.removeView(it) } }
        serviceScope.cancel()
    }

    companion object {
        private const val CHANNEL_ID = "game_booster_overlay"
        private const val NOTIF_ID = 42
    }
}
