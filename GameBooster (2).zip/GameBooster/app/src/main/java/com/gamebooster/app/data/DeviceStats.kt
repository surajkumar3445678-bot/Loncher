package com.gamebooster.app.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.view.Display
import android.view.WindowManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/**
 * All real readings, no made-up numbers.
 *
 * Limits, so nothing here is oversold:
 *  - "FPS" is the display's refresh rate (60/90/120Hz etc.), not another app's
 *    actual rendered frame rate. Reading another app's live FPS needs root
 *    (dumpsys gfxinfo) or Android's GPU profiling tools - we don't fake it.
 *  - RAM/CPU numbers are for the whole device, since a normal app cannot see
 *    inside another app's process on modern Android.
 */
data class DeviceSnapshot(
    val ramUsedPercent: Int,
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val batteryPercent: Int,
    val batteryTempC: Float,
    val refreshRateHz: Int,
    val pingMs: Long?
)

object DeviceStats {

    fun ramInfo(context: Context): Triple<Int, Long, Long> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val totalMb = info.totalMem / (1024 * 1024)
        val availMb = info.availMem / (1024 * 1024)
        val usedMb = totalMb - availMb
        val percent = if (totalMb > 0) ((usedMb * 100) / totalMb).toInt() else 0
        return Triple(percent, usedMb, totalMb)
    }

    fun batteryPercentAndTemp(context: Context): Pair<Int, Float> {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, filter)
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
        val tempTenths = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempC = tempTenths / 10f
        return Pair(percent, tempC)
    }

    fun refreshRateHz(context: Context): Int {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display: Display? = wm.defaultDisplay
        return display?.refreshRate?.toInt() ?: 60
    }

    /** Simple TCP-connect latency to a public DNS host - an honest stand-in for "ping". */
    suspend fun pingMs(host: String = "8.8.8.8", port: Int = 53, timeoutMs: Int = 1500): Long? =
        withContext(Dispatchers.IO) {
            try {
                val start = System.currentTimeMillis()
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, port), timeoutMs)
                }
                System.currentTimeMillis() - start
            } catch (e: Exception) {
                null
            }
        }

    suspend fun snapshot(context: Context): DeviceSnapshot {
        val (ramPct, ramUsed, ramTotal) = ramInfo(context)
        val (batPct, batTemp) = batteryPercentAndTemp(context)
        val refresh = refreshRateHz(context)
        val ping = pingMs()
        return DeviceSnapshot(ramPct, ramUsed, ramTotal, batPct, batTemp, refresh, ping)
    }
}
