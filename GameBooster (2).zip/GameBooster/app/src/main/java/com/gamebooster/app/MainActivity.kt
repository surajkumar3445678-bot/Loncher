package com.gamebooster.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.gamebooster.app.data.*
import com.gamebooster.app.service.OverlayService
import kotlinx.coroutines.launch

private val BgDark = Color(0xFF0B0714)
private val CardDark = Color(0xFF15101F)
private val Purple = Color(0xFF8B5CFF)
private val Cyan = Color(0xFF5BC4FF)
private val Green = Color(0xFF32E07A)
private val Gold = Color(0xFFFFC93F)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = BgDark, surface = CardDark)) {
                HomeScreen(
                    onRequestOverlay = ::requestOverlayPermission,
                    onStartOverlay = ::startOverlayService
                )
            }
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            startOverlayService()
        }
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}

@Composable
fun HomeScreen(onRequestOverlay: () -> Unit, onStartOverlay: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var snapshot by remember { mutableStateOf<DeviceSnapshot?>(null) }
    var selectedTab by remember { mutableStateOf(0) }
    var performanceMode by remember { mutableStateOf(PerformanceMode.GAMING) }
    var modeStatus by remember { mutableStateOf("") }

    val selectedGames by GameRepository.selectedGames(context).collectAsState(initial = emptySet())
    var showGamePicker by remember { mutableStateOf(false) }

    // Live stats, refreshed every 2s while Home is open.
    LaunchedEffect(Unit) {
        while (true) {
            snapshot = DeviceStats.snapshot(context)
            kotlinx.coroutines.delay(2000)
        }
    }

    Scaffold(
        containerColor = BgDark,
        bottomBar = { BottomNav(selectedTab) { selectedTab = it } }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BgDark)
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(16.dp))
            Text("GAME BOOSTER", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text("Play Smooth · Win More", color = Color(0xFF8A93A6), fontSize = 11.sp)
            Spacer(Modifier.height(20.dp))

            // Boost Now
            Box(contentAlignment = Alignment.Center) {
                Button(
                    onClick = {
                        val killed = Booster.boostNow(context)
                        modeStatus = "Freed background apps: $killed"
                    },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Purple),
                    modifier = Modifier.size(140.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Bolt, contentDescription = null, tint = Color.White)
                        Text("BOOST NOW", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
            if (modeStatus.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(modeStatus, color = Color(0xFF8A93A6), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }

            Spacer(Modifier.height(20.dp))

            // Device monitor - real numbers
            Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("DEVICE MONITOR", color = Color(0xFF8A93A6), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    val snap = snapshot
                    StatRow("RAM used", if (snap != null) "${snap.ramUsedPercent}% (${snap.ramUsedMb}/${snap.ramTotalMb} MB)" else "…")
                    StatRow("Battery", if (snap != null) "${snap.batteryPercent}%" else "…")
                    StatRow("Temp", if (snap != null) "${snap.batteryTempC}°C" else "…")
                    StatRow("Refresh rate", if (snap != null) "${snap.refreshRateHz} Hz" else "…")
                    StatRow("Ping (8.8.8.8)", if (snap != null) (snap.pingMs?.let { "${it} ms" } ?: "unreachable") else "…")
                }
            }

            Spacer(Modifier.height(14.dp))

            // Performance mode - real: tries a rooted governor switch, tells you honestly if it applied
            Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("PERFORMANCE MODE", color = Color(0xFF8A93A6), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    PerformanceMode.values().forEach { mode ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (mode == performanceMode) Purple else Color.Transparent)
                                .clickable {
                                    performanceMode = mode
                                    scope.launch {
                                        val applied = Booster.applyPerformanceMode(mode)
                                        modeStatus = if (applied) "${mode.name} applied (root)"
                                        else "${mode.name} selected - full effect needs root"
                                    }
                                }
                                .padding(10.dp)
                        ) {
                            Text(
                                mode.name.replace("_", " "),
                                color = if (mode == performanceMode) Color.White else Color(0xFFC6CCDA),
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // In-game overlay panel
            Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(14.dp)) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("In-game overlay", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Opens by sliding the edge handle while gaming", color = Color(0xFF8A93A6), fontSize = 10.sp)
                    }
                    Button(onClick = onRequestOverlay, colors = ButtonDefaults.buttonColors(containerColor = Cyan)) {
                        Text("Enable")
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Your Games - empty until the user adds some
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Your Games", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("Add", color = Purple, fontSize = 12.sp, modifier = Modifier.clickable { showGamePicker = true })
            }
            Spacer(Modifier.height(8.dp))

            if (selectedGames.isEmpty()) {
                Text(
                    "No games added yet - tap Add to pick from your installed games.",
                    color = Color(0xFF8A93A6), fontSize = 11.sp
                )
            } else {
                val installed = remember { GameRepository.listInstalledGames(context) }
                val chosen = installed.filter { it.packageName in selectedGames }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(chosen) { game ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .width(60.dp)
                                .clickable { GameRepository.launchGame(context, game.packageName) }
                        ) {
                            val bmp = remember(game.packageName) { game.icon?.toBitmap()?.asImageBitmap() }
                            if (bmp != null) {
                                androidx.compose.foundation.Image(
                                    bitmap = bmp, contentDescription = game.label,
                                    modifier = Modifier.size(50.dp).clip(RoundedCornerShape(12.dp))
                                )
                            } else {
                                Box(Modifier.size(50.dp).clip(RoundedCornerShape(12.dp)).background(CardDark))
                            }
                            Text(game.label, color = Color(0xFFC6CCDA), fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
        }
    }

    if (showGamePicker) {
        GamePickerDialog(
            installed = remember { GameRepository.listInstalledGames(context) },
            initiallySelected = selectedGames,
            onDismiss = { showGamePicker = false },
            onConfirm = { newSelection ->
                scope.launch { GameRepository.setSelectedGames(context, newSelection) }
                showGamePicker = false
            }
        )
    }
}

@Composable
fun GamePickerDialog(
    installed: List<InstalledGame>,
    initiallySelected: Set<String>,
    onDismiss: () -> Unit,
    onConfirm: (Set<String>) -> Unit
) {
    var selection by remember { mutableStateOf(initiallySelected) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardDark,
        title = { Text("Pick your games", color = Color.White) },
        text = {
            Column {
                if (installed.isEmpty()) {
                    Text("No games detected on this device yet.", color = Color(0xFF8A93A6))
                }
                installed.forEach { game ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selection = if (game.packageName in selection)
                                    selection - game.packageName else selection + game.packageName
                            }
                            .padding(vertical = 6.dp)
                    ) {
                        Checkbox(
                            checked = game.packageName in selection,
                            onCheckedChange = { checked ->
                                selection = if (checked) selection + game.packageName else selection - game.packageName
                            }
                        )
                        Text(game.label, color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(selection) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color(0xFFC6CCDA), fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
    Spacer(Modifier.height(4.dp))
}

@Composable
fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = BgDark) {
        val items = listOf(
            "Home" to Icons.Filled.Home,
            "Boost" to Icons.Filled.Bolt,
            "Games" to Icons.Filled.SportsEsports,
            "Stats" to Icons.Filled.BarChart,
            "Profile" to Icons.Filled.Person
        )
        items.forEachIndexed { index, (label, icon) ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Purple, selectedTextColor = Purple,
                    unselectedIconColor = Color(0xFF8A93A6), unselectedTextColor = Color(0xFF8A93A6),
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}
