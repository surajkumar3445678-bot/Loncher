package com.gamebooster.app.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.gameBoosterDataStore by preferencesDataStore(name = "game_booster_prefs")

data class InstalledGame(
    val packageName: String,
    val label: String,
    val icon: Drawable?
)

object GameRepository {

    private val SELECTED_GAMES_KEY = stringSetPreferencesKey("selected_games")

    /** "Your Games" starts empty - only what the user picks shows on Home. */
    fun selectedGames(context: Context): Flow<Set<String>> =
        context.gameBoosterDataStore.data.map { prefs ->
            prefs[SELECTED_GAMES_KEY] ?: emptySet()
        }

    suspend fun setSelectedGames(context: Context, packages: Set<String>) {
        context.gameBoosterDataStore.edit { prefs ->
            prefs[SELECTED_GAMES_KEY] = packages
        }
    }

    /**
     * All installed apps that look like games: Android's own CATEGORY_GAME flag
     * where a developer set it, plus the legacy FLAG_IS_GAME, plus a small
     * known-package fallback list since many popular games don't set either.
     */
    fun listInstalledGames(context: Context): List<InstalledGame> {
        val pm = context.packageManager
        val knownGamePackages = setOf(
            "com.dts.freefireth", "com.dts.freefiremax",
            "com.tencent.ig", "com.pubg.imobile", "com.pubg.krmobile",
            "com.mojang.minecraftpe",
            "com.miHoYo.GenshinImpact", "com.miHoYo.Yuanshen",
            "com.supercell.clashofclans", "com.supercell.clashroyale",
            "com.garena.game.codm"
        )

        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        return apps.filter { app ->
            val isSystemApp = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (isSystemApp) return@filter false

            val isCategoryGame = app.category == ApplicationInfo.CATEGORY_GAME
            @Suppress("DEPRECATION")
            val isLegacyGameFlag = (app.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            val isKnownGame = app.packageName in knownGamePackages

            isCategoryGame || isLegacyGameFlag || isKnownGame
        }.mapNotNull { app ->
            try {
                InstalledGame(
                    packageName = app.packageName,
                    label = pm.getApplicationLabel(app).toString(),
                    icon = pm.getApplicationIcon(app)
                )
            } catch (e: Exception) {
                null
            }
        }.sortedBy { it.label.lowercase() }
    }

    fun launchGame(context: Context, packageName: String) {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            context.startActivity(intent)
        }
    }
}
