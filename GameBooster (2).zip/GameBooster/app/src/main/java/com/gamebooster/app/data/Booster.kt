package com.gamebooster.app.data

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataOutputStream

enum class PerformanceMode { GAMING, BALANCED, POWER_SAVING }

object Booster {

    /**
     * Best-effort RAM free: asks the system to kill cached/background processes
     * of other apps. Modern Android limits how much a normal (non-system) app
     * can do here - this will not "boost FPS" by itself, it mainly frees RAM
     * that was sitting idle in app caches.
     */
    fun boostNow(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = context.packageManager
        val runningInfo = am.runningAppProcesses ?: emptyList()
        var killedCount = 0

        val ownPackage = context.packageName
        for (proc in runningInfo) {
            if (proc.importance < ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND) {
                continue // don't touch anything foreground or visible
            }
            for (pkg in proc.pkgList) {
                if (pkg == ownPackage) continue
                try {
                    am.killBackgroundProcesses(pkg)
                    killedCount++
                } catch (e: SecurityException) {
                    // expected on some OEM builds; just skip
                }
            }
        }
        System.gc()
        return killedCount
    }

    /**
     * Tries a rooted CPU-governor switch for Gaming mode. Silently does
     * nothing if the device isn't rooted or `su` denies the request - this
     * never crashes the app, and we tell the user in the UI whether it
     * actually applied.
     */
    suspend fun applyPerformanceMode(mode: PerformanceMode): Boolean = withContext(Dispatchers.IO) {
        val governor = when (mode) {
            PerformanceMode.GAMING -> "performance"
            PerformanceMode.BALANCED -> "schedutil"
            PerformanceMode.POWER_SAVING -> "powersave"
        }
        try {
            val process = ProcessBuilder("su").redirectErrorStream(true).start()
            val out = DataOutputStream(process.outputStream)
            // Apply to every CPU core's governor file if it exists.
            out.writeBytes(
                "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do " +
                    "echo $governor > \$f 2>/dev/null; done\n"
            )
            out.writeBytes("exit\n")
            out.flush()
            val code = process.waitFor()
            code == 0
        } catch (e: Exception) {
            false
        }
    }
}
