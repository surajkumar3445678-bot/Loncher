# Game Booster

## APK kaise banayein
1. Is folder ko GitHub repo mein push karo.
2. `.github/workflows/build.yml` khud chalega - Actions tab mein jaakar
   "GameBooster-debug-apk" artifact download karo.
3. Ya Android Studio mein kholke seedha Run karo (minSdk 26).

## Pehli baar app kholne par
- **Overlay permission**: Home screen par "Enable" dabaane par Settings
  khulegi, overlay allow karo - tabhi in-game panel edge-handle dikhega.
- **Do Not Disturb**: panel mein DND switch pehli baar dabaane par
  notification-access settings khulegi, ek baar allow karna padega.
- **Game Library**: "Your Games" khaali shuru hota hai - "Add" dabaakar
  apne installed games choose karo.

## Jo cheezein asli kaam karti hain
- RAM %, battery %, battery temperature, screen refresh rate, network
  ping - sab real system se.
- Boost Now - background (cached) apps ko free karta hai.
- Do Not Disturb toggle - asli system DND.
- Screenshot - MediaProjection se asli screenshot leta hai aur
  Pictures/GameBooster mein save karta hai.
- Your Games list - jo aap select karo wahi dikhta hai aur tap karne par
  launch hota hai.

## Jahan seema (limits) hai - imaandari se
- **FPS**: kisi doosre app ka asli frame-rate root ke bina dikhana
  Android par possible nahi hai. Yeh app display ka **refresh rate**
  (60/90/120Hz) dikhata hai, jo ek honest substitute hai.
- **Performance Mode (CPU governor switch)**: sirf **rooted** phone par
  kaam karega (aapka phone rooted hai, par OEM kernel ki wajah se kabhi
  kabhi `su` deny bhi kar sakta hai - app UI mein bata dega ki laागू hua
  ya nahi).
- **Network Boost / Touch Optimization**: Android normal apps ko doosre
  app ka network ya touch-sampling control karne nahi deta. Yeh abhi
  placeholder hain - agar chaho to inme rooted sysfs tweaks add kiye ja
  sakte hain, par device-specific hote hain.
- **Record (screen recording)**: abhi add nahi kiya hai (screenshot jaisa
  hi MediaProjection + MediaRecorder se banaya ja sakta hai agle step
  mein, agar chahiye).
